# Add project specific ProGuard rules here.
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
