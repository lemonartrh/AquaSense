package com.aquasense.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class ModesActivity extends AppCompatActivity {

    private static final String BASE_URL = "http://10.55.170.45";

    private TextView tvCurrentMode;
    private Button btnVannamei, btnCustom;
    private ImageButton btnBack;

    private final OkHttpClient httpClient = new OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modes);

        tvCurrentMode = findViewById(R.id.tvCurrentMode);
        btnVannamei = findViewById(R.id.btnVannamei);
        btnCustom = findViewById(R.id.btnCustom);
        btnBack = findViewById(R.id.btnBack);

        // Show current mode
        tvCurrentMode.setText(AppState.getInstance().getActiveMode());

        // Animate in
        View root = getWindow().getDecorView().getRootView();
        root.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));

        btnBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        });

        btnVannamei.setOnClickListener(v -> {
            callVannameiEndpoint();
        });

        btnCustom.setOnClickListener(v -> {
            Intent intent = new Intent(ModesActivity.this, CustomModeActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }

    private void callVannameiEndpoint() {
        btnVannamei.setEnabled(false);
        btnVannamei.setText("Sending…");

        Request request = new Request.Builder()
                .url(BASE_URL + "/vannamei")
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    btnVannamei.setEnabled(true);
                    btnVannamei.setText("🦐  VANNAMEI MODE");
                    Toast.makeText(ModesActivity.this,
                            "Connection failed: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(Call call, Response response) {
                runOnUiThread(() -> {
                    btnVannamei.setEnabled(true);
                    btnVannamei.setText("🦐  VANNAMEI MODE");

                    AppState.getInstance().setActiveMode("Vannamei");
                    tvCurrentMode.setText("Vannamei");

                    Toast.makeText(ModesActivity.this,
                            "✓ Vannamei mode activated",
                            Toast.LENGTH_SHORT).show();
                });
            }
        });
    }
}
