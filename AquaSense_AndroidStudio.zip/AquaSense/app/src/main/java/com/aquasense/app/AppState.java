package com.aquasense.app;

/**
 * Singleton to hold shared app state (active mode) across activities.
 */
public class AppState {

    private static AppState instance;
    private String activeMode = "Vannamei";

    private AppState() {}

    public static synchronized AppState getInstance() {
        if (instance == null) {
            instance = new AppState();
        }
        return instance;
    }

    public String getActiveMode() {
        return activeMode;
    }

    public void setActiveMode(String mode) {
        this.activeMode = mode;
    }
}
