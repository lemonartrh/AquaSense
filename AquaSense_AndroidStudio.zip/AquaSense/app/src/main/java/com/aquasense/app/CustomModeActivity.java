package com.aquasense.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class CustomModeActivity extends AppCompatActivity {

    private static final String BASE_URL = "http://10.55.170.45";

    private EditText etPH, etSalinity;
    private Button btnSend, btnHome;
    private ImageButton btnBack;
    private TextView tvStatus;

    private final OkHttpClient httpClient = new OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_mode);

        etPH = findViewById(R.id.etPH);
        etSalinity = findViewById(R.id.etSalinity);
        btnSend = findViewById(R.id.btnSend);
        btnHome = findViewById(R.id.btnHome);
        btnBack = findViewById(R.id.btnBack);
        tvStatus = findViewById(R.id.tvStatus);

        // Animate in
        View root = getWindow().getDecorView().getRootView();
        root.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));

        btnBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        });

        btnHome.setOnClickListener(v -> {
            Intent intent = new Intent(CustomModeActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        });

        btnSend.setOnClickListener(v -> validateAndSend());
    }

    private void validateAndSend() {
        String phStr = etPH.getText().toString().trim();
        String salStr = etSalinity.getText().toString().trim();

        if (TextUtils.isEmpty(phStr)) {
            etPH.setError("Enter a pH value");
            etPH.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(salStr)) {
            etSalinity.setError("Enter a salinity value");
            etSalinity.requestFocus();
            return;
        }

        double ph;
        int sal;
        try {
            ph = Double.parseDouble(phStr);
            sal = Integer.parseInt(salStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid numbers entered", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ph < 1 || ph > 14) {
            etPH.setError("pH must be between 1 and 14");
            return;
        }
        if (sal < 1 || sal > 40) {
            etSalinity.setError("Salinity must be between 1 and 40");
            return;
        }

        sendCustomParameters(phStr, salStr);
    }

    private void sendCustomParameters(String ph, String salinity) {
        btnSend.setEnabled(false);
        btnSend.setText("Sending…");
        tvStatus.setVisibility(View.GONE);

        // Build URL — adjust the endpoint path to match your ESP/server API
        String url = BASE_URL + "/custom?ph=" + ph + "&salinity=" + salinity;

        Request request = new Request.Builder()
                .url(url)
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    btnSend.setEnabled(true);
                    btnSend.setText("📤  SEND PARAMETERS");
                    showStatus("⚠ Connection failed: " + e.getMessage(), false);
                });
            }

            @Override
            public void onResponse(Call call, Response response) {
                runOnUiThread(() -> {
                    btnSend.setEnabled(true);
                    btnSend.setText("📤  SEND PARAMETERS");

                    if (response.isSuccessful()) {
                        AppState.getInstance().setActiveMode("Custom");
                        showStatus("✓ Parameters sent successfully!", true);
                    } else {
                        showStatus("⚠ Server error: " + response.code(), false);
                    }
                });
            }
        });
    }

    private void showStatus(String message, boolean isSuccess) {
        tvStatus.setText(message);
        tvStatus.setTextColor(isSuccess ? 0xFF00FFB3 : 0xFFFF4D6D);
        tvStatus.setVisibility(View.VISIBLE);
        tvStatus.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));
    }
}
