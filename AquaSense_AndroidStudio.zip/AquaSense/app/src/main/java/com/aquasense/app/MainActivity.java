package com.aquasense.app;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL = "http://10.55.170.45";
    private static final long POLL_INTERVAL_MS = 3000;

    private TextView tvPH, tvSalinity, tvActiveMode, tvConnectionStatus, tvPhStatus;
    private View liveDot;
    private Button btnModes;

    private final OkHttpClient httpClient = new OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .build();

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable pollRunnable = new Runnable() {
        @Override
        public void run() {
            fetchReadings();
            mainHandler.postDelayed(this, POLL_INTERVAL_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind views
        tvPH = findViewById(R.id.tvPH);
        tvSalinity = findViewById(R.id.tvSalinity);
        tvActiveMode = findViewById(R.id.tvActiveMode);
        tvConnectionStatus = findViewById(R.id.tvConnectionStatus);
        tvPhStatus = findViewById(R.id.tvPhStatus);
        liveDot = findViewById(R.id.liveDot);
        btnModes = findViewById(R.id.btnModes);

        // Animate live dot
        startLiveDotPulse();

        // Animate cards in
        animateCardsIn();

        // Navigate to modes
        btnModes.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ModesActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Restore mode label from shared prefs / AppState
        String mode = AppState.getInstance().getActiveMode();
        tvActiveMode.setText(mode);
        // Start polling
        mainHandler.post(pollRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mainHandler.removeCallbacks(pollRunnable);
    }

    private void fetchReadings() {
        Request request = new Request.Builder()
                .url(BASE_URL)
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> {
                    tvConnectionStatus.setText("●  OFFLINE");
                    tvConnectionStatus.setTextColor(0xFFFF4D6D);
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) return;
                String body = response.body() != null ? response.body().string().trim() : "";

                // Parse "ph,salinity" CSV format
                String[] parts = body.split(",");
                mainHandler.post(() -> {
                    if (parts.length >= 2) {
                        String phStr = parts[0].trim();
                        String salStr = parts[1].trim();

                        tvPH.setText(phStr);
                        tvSalinity.setText(salStr);
                        tvConnectionStatus.setText("●  LIVE");
                        tvConnectionStatus.setTextColor(0xFF00FFB3);

                        // Update pH status label
                        try {
                            double ph = Double.parseDouble(phStr);
                            updatePhStatus(ph);
                        } catch (NumberFormatException ignored) {}

                    } else if (!body.isEmpty()) {
                        // Fallback: single value
                        tvPH.setText(body);
                    }
                });
            }
        });
    }

    private void updatePhStatus(double ph) {
        if (ph >= 7.0 && ph <= 8.5) {
            tvPhStatus.setText("Optimal");
            tvPhStatus.setTextColor(0xFF00FFB3);
        } else if (ph >= 6.0 && ph < 7.0) {
            tvPhStatus.setText("Low");
            tvPhStatus.setTextColor(0xFFFFB830);
        } else if (ph > 8.5 && ph <= 10.0) {
            tvPhStatus.setText("High");
            tvPhStatus.setTextColor(0xFFFFB830);
        } else {
            tvPhStatus.setText("Critical");
            tvPhStatus.setTextColor(0xFFFF4D6D);
        }
    }

    private void startLiveDotPulse() {
        ObjectAnimator anim = ObjectAnimator.ofFloat(liveDot, "alpha", 1f, 0.2f);
        anim.setDuration(900);
        anim.setRepeatMode(ObjectAnimator.REVERSE);
        anim.setRepeatCount(ObjectAnimator.INFINITE);
        anim.start();
    }

    private void animateCardsIn() {
        View phCard = findViewById(R.id.phCard);
        View salCard = findViewById(R.id.salCard);

        if (phCard != null) {
            phCard.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));
        }
        if (salCard != null) {
            salCard.postDelayed(() ->
                salCard.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in)), 100);
        }
    }
}
