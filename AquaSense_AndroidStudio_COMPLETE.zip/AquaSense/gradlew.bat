@ECHO OFF
SET DIR=%~dp0
SET CLASSPATH=%DIR%gradle\wrapper\gradle-wrapper.jar

IF NOT EXIST "%CLASSPATH%" (
  ECHO ERROR: gradle-wrapper.jar not found in gradle\wrapper\
  ECHO Run 'gradle wrapper' on a machine with Gradle installed to regenerate it.
  EXIT /B 1
)

java -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
